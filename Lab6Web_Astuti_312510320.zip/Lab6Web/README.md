# Lab6Web – Praktikum 6: JavaScript DOM dan Event Handling

**Nama:** Astuti  
**NIM:** 312510320  
**Kelas:** I252A  
**Email:** astutifaza53@gmail.com  
**Usia (data uji):** 35 tahun  
**Mata Kuliah:** Pemrograman Web – Pertemuan 7

## Tujuan
1. Memahami DOM sebagai representasi dokumen HTML yang dapat diakses JavaScript.
2. Memilih elemen dengan id, class, dan selector CSS.
3. Mengubah teks, atribut, kelas CSS, dan gaya elemen.
4. Menangani event dengan `addEventListener()`.
5. Membuat validasi form dan menampilkan pesan sesuai kondisi input.
6. Membuat halaman interaktif dengan minimal tiga fungsi.

## Struktur File
```
Lab6Web/
├── index.html
├── style.css
├── script.js
├── README.md
├── laporan/Laporan_Praktikum6_Astuti_312510320.docx
└── screenshots/
```

## Cara Menjalankan
1. Unduh/clone repository `Lab6Web`.
2. Buka `index.html` di browser modern (Chrome/Edge/Firefox), atau gunakan ekstensi Live Server di VS Code.
3. Buka Developer Tools (F12) > Console untuk memeriksa error.

## Langkah Kerja
| Latihan | Ringkasan | Event / Method utama |
|---|---|---|
| 1 | Mengubah judul dan paragraf | `getElementById`, `textContent` |
| 2 | Tombol menampilkan waktu klik | `click`, `new Date().toLocaleTimeString()` |
| 3 | Mengubah gaya paragraf | `classList.toggle()` |
| 4 | Penghitung karakter nama | `input`, `value.length` |
| 5 | Validasi form pendaftaran (nama, email, usia) | `submit`, `preventDefault()`, regex |
| 6 | To-do list | `createElement`, `appendChild`, `classList.toggle()` |
| Mini Project | Pendaftaran workshop: validasi nama/email/sesi, ringkasan langsung, penghitung karakter catatan, tombol hapus input | `submit`, `input`, `change`, `click` |

### Eksperimen Mandiri
1. **Hapus item to-do:** tombol "Hapus" ditambahkan pada setiap tugas (`item.remove()`).
2. **Nama minimal 3 karakter:** diterapkan pada Latihan 5 dan Mini Project.
3. **Event `change` dropdown sesi:** sesi terpilih tampil di bawah dropdown dan pada ringkasan.
4. **Sembunyikan/tampilkan paragraf:** `classList.toggle("tersembunyi")` dengan `display: none`.
5. **Script tanpa `defer` di `<head>`:** script berjalan saat HTML belum selesai diparsing, sehingga `getElementById()` mengembalikan `null` dan muncul error `Cannot set properties of null (setting 'textContent')`. Penyebabnya, elemen belum ada di DOM ketika kode dieksekusi. Solusi: pakai atribut `defer`, letakkan `<script>` sebelum `</body>`, atau bungkus kode dengan event `DOMContentLoaded`.

### Skenario Pengujian Validasi Form (Latihan 5)
| No | Kondisi | Hasil yang diharapkan |
|---|---|---|
| 1 | Semua kosong | "Nama wajib diisi." |
| 2 | Nama kosong, lainnya terisi | "Nama wajib diisi." |
| 3 | Nama 2 huruf | "Nama minimal terdiri dari 3 karakter." |
| 4 | Email tidak valid (`astuti@`) | "Masukkan email yang valid." |
| 5 | Usia 16 | "Usia harus berupa bilangan bulat 17–100." |
| 6 | Semua valid: nama Astuti, email astutifaza53@gmail.com, usia 35 | "Validasi berhasil. Form siap diproses." dan form di-reset |

## Screenshot
Data uji valid: nama **Astuti**, email **astutifaza53@gmail.com**, usia **35**.

**Latihan 1: judul dan pesan diubah**

![Latihan 1: judul dan pesan diubah](screenshots/latihan1-judul-pesan.png)

**Latihan 2: pesan waktu klik**

![Latihan 2: pesan waktu klik](screenshots/latihan2-klik.png)

**Latihan 3: tampilan awal**

![Latihan 3: tampilan awal](screenshots/latihan3-awal.png)

**Latihan 3: setelah toggle gaya**

![Latihan 3: setelah toggle gaya](screenshots/latihan3-gaya.png)

**Eksperimen 4: paragraf disembunyikan**

![Eksperimen 4: paragraf disembunyikan](screenshots/latihan3-sembunyi.png)

**Latihan 4: penghitung karakter (Astuti = 6)**

![Latihan 4: penghitung karakter (Astuti = 6)](screenshots/latihan4-karakter.png)

**Latihan 5: semua kosong**

![Latihan 5: semua kosong](screenshots/latihan5-1-kosong.png)

**Latihan 5: nama kurang dari 3 karakter**

![Latihan 5: nama kurang dari 3 karakter](screenshots/latihan5-2-nama-pendek.png)

**Latihan 5: email tidak valid**

![Latihan 5: email tidak valid](screenshots/latihan5-3-email-salah.png)

**Latihan 5: usia 16 (di bawah 17)**

![Latihan 5: usia 16 (di bawah 17)](screenshots/latihan5-4-usia-16.png)

**Latihan 5: valid (Astuti, astutifaza53@gmail.com, usia 35)**

![Latihan 5: valid (Astuti, astutifaza53@gmail.com, usia 35)](screenshots/latihan5-5-valid.png)

**Latihan 6: tugas kosong**

![Latihan 6: tugas kosong](screenshots/latihan6-kosong.png)

**Latihan 6: tugas ditambah dan ditandai selesai**

![Latihan 6: tugas ditambah dan ditandai selesai](screenshots/latihan6-tugas.png)

**Eksperimen 1: tugas dihapus**

![Eksperimen 1: tugas dihapus](screenshots/latihan6-hapus.png)

**Mini project: form kosong**

![Mini project: form kosong](screenshots/mini-1-kosong.png)

**Mini project: email tidak valid**

![Mini project: email tidak valid](screenshots/mini-2-email-salah.png)

**Mini project: sesi belum dipilih**

![Mini project: sesi belum dipilih](screenshots/mini-3-sesi-kosong.png)

**Mini project: ringkasan dan penghitung karakter langsung**

![Mini project: ringkasan dan penghitung karakter langsung](screenshots/mini-4-input-live.png)

**Mini project: pendaftaran berhasil**

![Mini project: pendaftaran berhasil](screenshots/mini-5-sukses.png)

**Mini project: setelah Hapus input**

![Mini project: setelah Hapus input](screenshots/mini-6-reset.png)

**Eksperimen 5: error tanpa defer**

![Eksperimen 5: error tanpa defer](screenshots/eksperimen5-tanpa-defer.png)

## Jawaban Pertanyaan Evaluasi
1. **DOM** (Document Object Model) adalah representasi dokumen HTML dalam bentuk pohon objek. Manfaatnya: JavaScript dapat memilih elemen, mengubah konten/atribut/gaya, menambah atau menghapus elemen, dan merespons aksi pengguna sehingga halaman menjadi dinamis.
2. `getElementById()` memilih satu elemen berdasarkan id. `querySelector()` memilih elemen **pertama** yang cocok dengan selector CSS. `querySelectorAll()` memilih **semua** elemen yang cocok dan mengembalikan NodeList.
3. `addEventListener()` menghubungkan sebuah event dengan fungsi yang dijalankan saat event terjadi, dan dapat dipasang lebih dari satu pada elemen yang sama. Contoh event: `click`, `input`, `submit` (juga `change`, `keydown`, `mouseover`).
4. `event.preventDefault()` mencegah perilaku bawaan submit (halaman dimuat ulang/data terkirim) sehingga program dapat memeriksa data dan menampilkan pesan validasi terlebih dahulu.
5. `textContent` menampilkan teks biasa sehingga aman untuk input pengguna. `innerHTML` mengurai string sebagai markup HTML sehingga dapat mengubah struktur elemen, tetapi berisiko XSS bila diisi teks pengguna yang tidak dipercaya.
6. `classList.toggle()` menambah kelas jika belum ada dan menghapusnya jika sudah ada, sehingga satu tombol dapat mengganti tampilan elemen (mis. `highlight`, `teks-besar`) tanpa mengubah gaya langsung lewat JavaScript.
7. Skenario pengujian: (a) semua input kosong, (b) nama kosong atau kurang dari 3 karakter, (c) format email salah, (d) usia di bawah 17 atau di atas 100 atau bukan bilangan bulat, (e) semua input valid.

## Perbedaan `classList.add()`, `remove()`, `toggle()`
- `add("x")`: menambahkan kelas (tidak ganda jika sudah ada).
- `remove("x")`: menghapus kelas.
- `toggle("x")`: menambah bila belum ada, menghapus bila sudah ada.
