// ===== Latihan 1: mengubah teks dengan DOM =====
const judul = document.getElementById("judul");
const pesan = document.getElementById("pesan");
judul.textContent = "Belajar JavaScript DOM";
pesan.textContent = "Konten berhasil diubah oleh JavaScript.";

// ===== Latihan 2: event click =====
const tombol = document.getElementById("tombolAksi");
tombol.addEventListener("click", function () {
  pesan.textContent = "Tombol diklik pada " + new Date().toLocaleTimeString();
});

// ===== Latihan 3: classList =====
const tombolGaya = document.getElementById("tombolGaya");
const teksGaya = document.getElementById("teksGaya");
tombolGaya.addEventListener("click", function () {
  teksGaya.classList.toggle("highlight");
  teksGaya.classList.toggle("teks-besar");
});

// Eksperimen 4: sembunyikan/tampilkan paragraf dengan class CSS
document.getElementById("tombolSembunyi").addEventListener("click", function () {
  document.getElementById("paragrafToggle").classList.toggle("tersembunyi");
});

// ===== Latihan 4: penghitung karakter =====
const namaInput = document.getElementById("namaInput");
const jumlahKarakter = document.getElementById("jumlahKarakter");
namaInput.addEventListener("input", function () {
  jumlahKarakter.textContent = namaInput.value.length;
});

// ===== Fungsi bantu pesan =====
function tampilkanPesan(elemen, teks, sukses) {
  elemen.textContent = teks;
  elemen.classList.remove("pesan-error", "pesan-sukses");
  elemen.classList.add(sukses ? "pesan-sukses" : "pesan-error");
}
const polaEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ===== Latihan 5: validasi form (Eksperimen 2: nama minimal 3 karakter) =====
const form = document.getElementById("formPendaftaran");
const pesanForm = document.getElementById("pesanForm");
form.addEventListener("submit", function (event) {
  event.preventDefault();
  const nama = document.getElementById("nama").value.trim();
  const email = document.getElementById("email").value.trim();
  const usiaInput = document.getElementById("usia").value;
  const usia = Number(usiaInput);

  if (nama === "") {
    tampilkanPesan(pesanForm, "Nama wajib diisi.", false);
  } else if (nama.length < 3) {
    tampilkanPesan(pesanForm, "Nama minimal terdiri dari 3 karakter.", false);
  } else if (!polaEmail.test(email)) {
    tampilkanPesan(pesanForm, "Masukkan email yang valid.", false);
  } else if (usiaInput === "" || !Number.isInteger(usia) || usia < 17 || usia > 100) {
    tampilkanPesan(pesanForm, "Usia harus berupa bilangan bulat 17–100.", false);
  } else {
    tampilkanPesan(pesanForm, "Validasi berhasil. Form siap diproses.", true);
    form.reset();
  }
});

// ===== Latihan 6: To-do list (Eksperimen 1: tombol hapus) =====
const inputTugas = document.getElementById("inputTugas");
const tambahTugas = document.getElementById("tambahTugas");
const daftarTugas = document.getElementById("daftarTugas");
const pesanTugas = document.getElementById("pesanTugas");

tambahTugas.addEventListener("click", function () {
  const teks = inputTugas.value.trim();
  if (teks === "") {
    tampilkanPesan(pesanTugas, "Tulis tugas terlebih dahulu.", false);
    return;
  }
  const item = document.createElement("li");
  const label = document.createElement("span");
  const selesai = document.createElement("button");
  const hapus = document.createElement("button");

  label.textContent = teks + " ";
  selesai.type = "button";
  selesai.textContent = "Tandai selesai";
  selesai.addEventListener("click", function () {
    item.classList.toggle("selesai");
    selesai.textContent = item.classList.contains("selesai")
      ? "Batalkan selesai" : "Tandai selesai";
  });

  hapus.type = "button";
  hapus.textContent = "Hapus";
  hapus.classList.add("sekunder");
  hapus.addEventListener("click", function () {
    item.remove();
    tampilkanPesan(pesanTugas, "Tugas dihapus.", true);
  });

  item.append(label, selesai, hapus);
  daftarTugas.appendChild(item);
  inputTugas.value = "";
  tampilkanPesan(pesanTugas, "Tugas ditambahkan.", true);
  inputTugas.focus();
});

// ===== Mini Project: pendaftaran workshop =====
const formWs = document.getElementById("formWorkshop");
const wsNama = document.getElementById("wsNama");
const wsEmail = document.getElementById("wsEmail");
const wsSesi = document.getElementById("wsSesi");
const wsCatatan = document.getElementById("wsCatatan");
const wsHitung = document.getElementById("wsHitung");
const pesanWs = document.getElementById("pesanWorkshop");
const infoSesi = document.getElementById("infoSesi");
const rNama = document.getElementById("rNama");
const rEmail = document.getElementById("rEmail");
const rSesi = document.getElementById("rSesi");

function perbaruiRingkasan() {
  rNama.textContent = wsNama.value.trim() || "-";
  rEmail.textContent = wsEmail.value.trim() || "-";
  rSesi.textContent = wsSesi.value || "-";
}

wsNama.addEventListener("input", perbaruiRingkasan);
wsEmail.addEventListener("input", perbaruiRingkasan);
wsCatatan.addEventListener("input", function () {
  wsHitung.textContent = wsCatatan.value.length;
});

// Eksperimen 3: event change pada dropdown sesi
wsSesi.addEventListener("change", function () {
  infoSesi.textContent = wsSesi.value
    ? "Sesi dipilih: " + wsSesi.value
    : "Belum ada sesi dipilih.";
  perbaruiRingkasan();
});

function tandaiSalah(elemen, salah) {
  elemen.classList.toggle("input-salah", salah);
}

formWs.addEventListener("submit", function (event) {
  event.preventDefault();
  const nama = wsNama.value.trim();
  const email = wsEmail.value.trim();
  let galat = "";
  let target = null;

  if (nama.length < 3) {
    galat = nama === "" ? "Nama wajib diisi." : "Nama minimal terdiri dari 3 karakter.";
    target = wsNama;
  } else if (!polaEmail.test(email)) {
    galat = "Masukkan email yang valid, contoh: nama@contoh.com.";
    target = wsEmail;
  } else if (wsSesi.value === "") {
    galat = "Pilih salah satu sesi workshop.";
    target = wsSesi;
  }

  [wsNama, wsEmail, wsSesi].forEach(function (el) { tandaiSalah(el, el === target); });

  if (galat) {
    tampilkanPesan(pesanWs, galat, false);
    target.focus();
    return;
  }
  tampilkanPesan(pesanWs, "Pendaftaran berhasil. Terima kasih, " + nama + "!", true);
  formWs.reset();
  wsHitung.textContent = "0";
  infoSesi.textContent = "Belum ada sesi dipilih.";
  perbaruiRingkasan();
});

// Tombol hapus input
document.getElementById("wsReset").addEventListener("click", function () {
  formWs.reset();
  [wsNama, wsEmail, wsSesi].forEach(function (el) { tandaiSalah(el, false); });
  wsHitung.textContent = "0";
  infoSesi.textContent = "Belum ada sesi dipilih.";
  pesanWs.textContent = "";
  perbaruiRingkasan();
});
